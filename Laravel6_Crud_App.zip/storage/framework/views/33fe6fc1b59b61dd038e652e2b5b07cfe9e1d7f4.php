<!DOCTYPE html>

<html>

<head>

    <title>Laravel 6 CRUD Application </title>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">

</head>

<body>

  

<div class="container" style="margin:100px auto;width:70%;border:1px solid #eee;padding:20px;">

    <?php echo $__env->yieldContent('content'); ?>

</div>

   

</body>

</html><?php /**PATH C:\xampp\htdocs\laravel6_crud_app\resources\views/users/layout.blade.php ENDPATH**/ ?>