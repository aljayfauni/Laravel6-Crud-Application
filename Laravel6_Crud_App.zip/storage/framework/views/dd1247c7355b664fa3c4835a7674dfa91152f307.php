  

<?php $__env->startSection('content'); ?>

<div class="row" >

    <div class="col-lg-12 margin-tb">

        <div class="pull-left">

            <h2>Add New User</h2>

        </div>

        <div class="pull-right">

            <a class="btn btn-primary" href="<?php echo e(route('users.index')); ?>"> Back</a>

        </div>

    </div>

</div>

   

<?php if($errors->any()): ?>

    <div class="alert alert-danger">

        <strong>oops!</strong> erro input!<br><br>

        <ul>

            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <li><?php echo e($error); ?></li>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>

    </div>

<?php endif; ?>

   

<form action="<?php echo e(route('users.add_user')); ?>" method="POST" enctype="multipart/form-data">

    <?php echo csrf_field(); ?>

  

     <div class="row">

        <div class="col-xs-12 col-sm-12 col-md-12">

            <div class="form-group">

                <strong>FirstName:</strong>

                <input type="text" name="fname" class="form-control" placeholder="FirstName">

            </div>

        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">

            <div class="form-group">

                <strong>LastName:</strong>

                <input type="text" name="lname" class="form-control" placeholder="LastName">

            </div>

        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">

            <div class="form-group">

                <strong>Email:</strong>

                <input type="text" name="email" class="form-control" placeholder="Email">

            </div>

            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">

            <div class="form-group">

                <strong>Birthday:</strong>

                <input type="date" name="bday"  class="form-control" placeholder="Birthday">

            </div>

            </div>

                        <div class="col-xs-12 col-sm-12 col-md-12">

            <div class="form-group">

                <strong>Upload Profile:</strong>

                <input type="file" name="profile"  class="form-control" >

            </div>

            </div>

        <div class="col-xs-12 col-sm-12 col-md-12 text-center">

                <button type="submit" class="btn btn-primary">Submit</button>

        </div>

    </div>

   

</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('users.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel6_crud_app\resources\views/users/create.blade.php ENDPATH**/ ?>